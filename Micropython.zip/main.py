from machine import Pin, I2C, Timer
from time import ticks_ms, time
import ssd1306
import random

# Inicialización de la pantalla OLED
i2c = I2C(0, scl=Pin(22), sda=Pin(21))
oled_width = 128
oled_height = 64
oled = ssd1306.SSD1306_I2C(oled_width, oled_height, i2c)

# Clase para el menú
class Menu:
    def __init__(self):
        self.items = []
        self.index = 0

    def add_item(self, text, action):
        self.items.append((text, action))

    def Up(self):
        self.index = (self.index - 1) % len(self.items)
        self.display_current_option()

    def down(self):
        self.index = (self.index + 1) % len(self.items)
        self.display_current_option()

    def enter(self):
        _, action = self.items[self.index]
        action()

    def display_current_option(self):
        oled.fill(0)
        oled.text(self.items[self.index][0], 0, 0)
        oled.show()

menu = Menu()

# Definición de las funciones de las opciones del menú
def opcion0():
    temperatura()
    grados = random.randint(0, 240)
    texto = "{}C".format(grados)
    print("Temperatura actual:", texto)
    oled.fill(0)
    oled.text("Temperatura:", 0, 0)
    oled.show()

def opcion1():
    global led1
    led1.value(not led1.value())
    cronometro()
    tiempo_transcurrido = int(time())
    horas = tiempo_transcurrido // 3600
    minutos = (tiempo_transcurrido % 3600) // 60
    segundos = tiempo_transcurrido % 60
    tiempo_formateado = "{:02d}:{:02d}.{:02d}".format(horas, minutos, segundos)
    print("Cronómetro actual:", tiempo_formateado)
    print("LED 1:", "Encendido" if led1.value() else "Apagado")
    oled.fill(0)
    oled.text("Cronómetro:", 0, 0)
    oled.text(tiempo_formateado, 0, 16)
    oled.show()

def opcion2():
    global led2
    led2.value(not led2.value())
    estado_led2 = "Encendido" if led2.value() else "Apagado"
    print("Estado LED 2:", estado_led2)
    oled.fill(0)
    oled.text("Estado LED 2:", 0, 0)
    oled.text(estado_led2, 0, 16)
    oled.show()

# Añadir las opciones al menú
menu.add_item("opcion 0", opcion0)
menu.add_item("opcion 1", opcion1)
menu.add_item("opcion 2", opcion2)

# Inicialización de los pines para los LEDs y botones
led1 = Pin(5, Pin.OUT)
led2 = Pin(15, Pin.OUT)

btnUp = Pin(27, Pin.IN, Pin.PULL_UP)
btndown = Pin(14, Pin.IN, Pin.PULL_UP)
btnenter = Pin(26, Pin.IN, Pin.PULL_UP)

# Variables para controlar el tiempo entre pulsaciones de botones
last_time = 0
debounce_time = 200  # Tiempo de rebote en milisegundos

# Función para manejar las interrupciones de botones
def button_handler(pin):
    global last_time
    current_time = ticks_ms()
    if current_time - last_time >= debounce_time:
        if pin == btnUp:
            menu.Up()
        elif pin == btndown:
            menu.down()
        elif pin == btnenter:
            menu.enter()
        last_time = current_time

# Configurar las interrupciones de botones
btnUp.irq(handler=button_handler, trigger=Pin.IRQ_FALLING)
btndown.irq(handler=button_handler, trigger=Pin.IRQ_FALLING)
btnenter.irq(handler=button_handler, trigger=Pin.IRQ_FALLING)

# Función para mostrar la temperatura en la pantalla OLED
def temperatura():
    grados = random.randint(0, 240)
    texto = "{}C".format(grados)
    oled.fill(0)
    oled.text('temp:', 0, 0)
    oled.text(texto, 33, 0)
    oled.show()

# Función para mostrar el cronómetro en la pantalla OLED
def cronometro():
    tiempo_transcurrido = int(time())
    horas = tiempo_transcurrido // 3600
    minutos = (tiempo_transcurrido % 3600) // 60
    segundos = tiempo_transcurrido % 60
    tiempo_formateado = "{:02d}:{:02d}.{:02d}".format(horas, minutos, segundos)
    oled.fill(0)
    oled.text('crono:', 0, 0)
    oled.text(tiempo_formateado, 45, 0)
    oled.show()
